

document.addEventListener('DOMContentLoaded', function() {
   const can = document.querySelector("#canid");    
   // поле
const data = can.getContext('2d');
const grid = 15; //граница
const racket = grid * 5;
// координаты

data.filStyle = ("black");
const MaxRacketY = can.height - grid - racket;
const Lracket = {x: grid * 2, y: can.height / 2 - racket, width: grid, height: racket, dy: 0 ,};
const Rracket = {x: can.width - grid * 3, y: can.height / 2 - racket.height / 2, width: grid, height: racket, dy: 0};
// координаты ракеток

   



  const BallSP = 7; // скорость мяча 
  const RacketSP = 7;
  const ball = {x: can.width / 2, y: can.height / 2,
   width: grid, height: grid, dx: BallSP, dy: -BallSP, 
   // исрес -  это значение которое указывает был ли мяч сброшен 
   isres: false                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
  }
// харакеристика мяча

function render() {
   data.fillRect(0, 0, can.width, grid);
   data.fillRect(0, can.height - grid, can.width, grid);
    for(let i = grid; i < can.height - grid; i = i + grid * 2){
      data.fillRect(can.width / 2, i, grid, grid)
   };

}
// рендеринг карты


function clear () {
   data.clearRect(0, 0, can.width, can.height);
};
// функция очистки кана


function drawL () {
data.fillRect(Lracket.x, Lracket.y, Lracket.width, Lracket.height);
}
// отрисовка левой ракетки


function drawR () {
   data.fillRect(Rracket.x, Rracket.y, Rracket.width, Rracket.height);
}
// отрисовка правой ракетки


function moveRacket () {
   Lracket.y += Lracket.dy;
   Rracket.y += Rracket.dy;
}
// движение ракеток


function drawBall () {
   data.fillRect(ball.x, ball.y, ball.width, ball.height);
}
// функция отрисовки мяча


function moveBall () {
   ball.y += ball.dy;
   ball.x += ball.dx
}
// движение мяча


function reset () {
   if((ball.x < 0 || ball.x > can.width) && !ball.isResertted){
      ball.isResertted = true //для мяча чтобы небыло второго сброса 
      setTimeout(() => {ball.x = can.width / 2;
         ball.y = can.height / 2;   // смещение мяча в центр после ресета
         ball.isResertted = false; 
      }, 1000) 
   }
}


function borders (tennis) {
   if(tennis.y < grid){tennis.y = grid}
   else if(tennis.y > MaxRacketY){tennis.y = MaxRacketY}
}  //макс границы для ракеток


function border() {
   borders(Lracket);
   borders(Rracket);
}

function borderBall() {
   if(ball.y < grid){ball.y = grid,
      ball.dy =- ball.dy
   }
      else if(ball.y > can.height - grid){
      ball.y = can.height - grid, 
      // ball.dy =- ball.dy
      ball.dy *= -1
   }    
}; //скачок мяча от границ кана


function racketKick (object1, object2) {
   const w1 = object1.x + object1.width;
   const w2 = object2.x + object2.width;
   const h1 = object1.y + object1.height;
   const h2 = object2.y + object2.height;

   return(object1.x < w2 && object2.x < w1
       && 
       object1.y < h2 && object2.y < h1)
};   //проверка на столкновение с ракеткой


function checkKick () {
   if(racketKick(Rracket, ball)){
      ball.dx = -ball.dx,
      ball.x = Rracket.x - ball.width
   }
   else if(racketKick(Lracket, ball)){
      ball.dx = -ball.dx,
      ball.x = Lracket.x + ball.width
   }
}; //обработка отскоков мяча


function bot () {
   let direction = 0;
   if(ball.x > Math.random() * can.width / 2){
      if(ball.y < Rracket.y){
         direction = -1;
      }
      else if(ball.y > Rracket.y + racket){
         direction = 1
      }
      else(Rracket.dy = 0)
   }  // бот на ракетку
Rracket.y += RacketSP * direction

};

function play () { //вызов игры
   clear();
   drawL();
   drawR();
   bot();
   moveRacket();
   borderBall();
   drawBall();
   moveBall();
   border();
   checkKick();
   reset();   
   render();
   requestAnimationFrame(play);

};
document.addEventListener("keydown", (event) =>
{if(event.key === "w" || event.key === "ц"){
   Lracket.dy = -RacketSP;
}
else if(event.key === "s" || event.key === "ы"){
   Lracket.dy = RacketSP;  //управление ракеткой
}})
requestAnimationFrame(play);



});


